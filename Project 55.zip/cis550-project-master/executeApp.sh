#/bin/bash

export DYLD_LIBRARY_PATH=$OCI_LIB_DIR
nodemon app.js
